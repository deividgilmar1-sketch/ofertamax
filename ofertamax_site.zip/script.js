const products = [
 {id:1,name:"Fone Bluetooth Pro",cat:"Eletrônicos",icon:"🎧",old:199.90,price:89.90,discount:55},
 {id:2,name:"Smartwatch Fit",cat:"Eletrônicos",icon:"⌚",old:299.90,price:149.90,discount:50},
 {id:3,name:"Tênis Casual Urban",cat:"Moda",icon:"👟",old:249.90,price:119.90,discount:52},
 {id:4,name:"Luminária LED",cat:"Casa",icon:"💡",old:129.90,price:59.90,discount:54},
 {id:5,name:"Teclado Gamer RGB",cat:"Games",icon:"⌨️",old:229.90,price:129.90,discount:43},
 {id:6,name:"Caixa de Som",cat:"Eletrônicos",icon:"🔊",old:189.90,price:99.90,discount:47},
 {id:7,name:"Mochila Premium",cat:"Moda",icon:"🎒",old:179.90,price:89.90,discount:50},
 {id:8,name:"Air Fryer Compacta",cat:"Casa",icon:"🍟",old:399.90,price:229.90,discount:43}
];
let cart = JSON.parse(localStorage.getItem("ofertamax-cart")||"[]");
let currentCategory="Todos", query="";

const money=v=>v.toLocaleString("pt-BR",{style:"currency",currency:"BRL"});
function render(){
 const list=products.filter(p=>(currentCategory==="Todos"||p.cat===currentCategory)&&p.name.toLowerCase().includes(query.toLowerCase()));
 document.getElementById("resultCount").textContent=`${list.length} ofertas`;
 document.getElementById("products").innerHTML=list.map(p=>`
 <article class="product">
  <div class="pic"><span class="discount">-${p.discount}%</span>${p.icon}</div>
  <div class="info"><small>${p.cat}</small><h3>${p.name}</h3><span class="old">${money(p.old)}</span><span class="price">${money(p.price)}</span>
  <button class="buy" onclick="addToCart(${p.id})">Adicionar ao carrinho</button></div>
 </article>`).join("");
 document.getElementById("empty").hidden=list.length!==0;
 renderCart();
}
function addToCart(id){
 const item=cart.find(x=>x.id===id);
 if(item)item.qty++; else cart.push({id,qty:1});
 save(); openCart();
}
function changeQty(id,delta){
 const item=cart.find(x=>x.id===id); if(!item)return;
 item.qty+=delta; if(item.qty<=0)cart=cart.filter(x=>x.id!==id);
 save(); renderCart();
}
function renderCart(){
 const count=cart.reduce((s,x)=>s+x.qty,0);
 document.getElementById("cartCount").textContent=count;
 const items=document.getElementById("cartItems");
 items.innerHTML=cart.length?cart.map(x=>{const p=products.find(y=>y.id===x.id);return `
 <div class="cart-item"><div class="mini">${p.icon}</div><div><h4>${p.name}</h4><strong>${money(p.price)}</strong>
 <div class="qty"><button onclick="changeQty(${p.id},-1)">−</button>${x.qty}<button onclick="changeQty(${p.id},1)">+</button></div></div></div>`}).join(""):`<p style="color:#777;text-align:center;padding:40px 0">Seu carrinho está vazio.</p>`;
 const total=cart.reduce((s,x)=>s+products.find(p=>p.id===x.id).price*x.qty,0);
 document.getElementById("cartTotal").textContent=money(total);
}
function save(){localStorage.setItem("ofertamax-cart",JSON.stringify(cart));renderCart()}
function openCart(){document.getElementById("cart").classList.add("open");document.getElementById("overlay").classList.add("open")}
function closeCart(){document.getElementById("cart").classList.remove("open");document.getElementById("overlay").classList.remove("open")}
document.querySelectorAll(".category").forEach(b=>b.onclick=()=>{document.querySelectorAll(".category").forEach(x=>x.classList.remove("active"));b.classList.add("active");currentCategory=b.dataset.category;render()});
document.getElementById("searchInput").oninput=e=>{query=e.target.value;render()};
document.getElementById("searchBtn").onclick=()=>document.getElementById("searchInput").focus();
document.getElementById("cartBtn").onclick=openCart;
document.getElementById("closeCart").onclick=closeCart;
document.getElementById("overlay").onclick=closeCart;
document.getElementById("checkout").onclick=()=>alert("Demo: conecte aqui seu checkout/pagamento.");
let end=Date.now()+8*60*60*1000;
function timer(){let t=Math.max(0,end-Date.now()),s=Math.floor(t/1000);document.getElementById("hours").textContent=String(Math.floor(s/3600)).padStart(2,"0");document.getElementById("minutes").textContent=String(Math.floor(s%3600/60)).padStart(2,"0");document.getElementById("seconds").textContent=String(s%60).padStart(2,"0")}
setInterval(timer,1000);timer();render();